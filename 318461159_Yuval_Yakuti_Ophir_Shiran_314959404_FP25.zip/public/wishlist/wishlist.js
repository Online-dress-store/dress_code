// Import navigation and shared helpers
import { createNavigation, initNavigation, updateAuthStatus } from "../shared/navigation.js";
import { addToCart } from "../shared/cart.js";
import { getWishlist as getWishlistShared, removeFromWishlist as removeWishlistShared } from "../shared/wishlist.js";

// DOM elements
const emptyWishlistElement = document.getElementById('emptyWishlist');
const wishlistGridElement = document.getElementById('wishlistGrid');

// Initialize wishlist
document.addEventListener('DOMContentLoaded', async function() {
  // Load navigation
  const navigationElement = document.getElementById('navigation');
  if (navigationElement) {
    navigationElement.innerHTML = createNavigation();
    initNavigation();
    await updateAuthStatus();
  }
  
  // Check authentication first
  const authCheck = new AuthCheck();
  const isAuthenticated = await authCheck.init();
  
  if (!isAuthenticated) {
    return; // Stop execution if not authenticated
  }
  
  // Get current user for wishlist data
  const currentUser = authCheck.getCurrentUser();
  
  // Load wishlist data from localStorage (if any exists)
  loadWishlistFromStorage();
  
  // Render the wishlist based on current state
  renderWishlist();
});

// Load wishlist data from localStorage
async function loadWishlistFromStorage() {
  try {
    const list = getWishlistShared();
    // sanitize: keep only valid items with id
    const sanitized = Array.isArray(list) ? list.filter(i => i && typeof i.id !== 'undefined') : [];
    // If there were invalid items, persist the cleaned list
    if (sanitized.length !== (Array.isArray(list) ? list.length : 0)) {
      try {
        const mod = await import('../shared/wishlist.js');
        if (mod && typeof mod.setWishlist === 'function') mod.setWishlist(sanitized);
      } catch (_) {}
    }
    if (sanitized.length > 0) return sanitized;
  } catch (error) {
    console.error('Error loading wishlist from storage:', error);
  }
  return [];
}

// Render wishlist
async function renderWishlist() {
  const wishlistItems = await loadWishlistFromStorage();
  
  if (wishlistItems.length === 0) {
    // Show empty state
    emptyWishlistElement.style.display = 'block';
    wishlistGridElement.style.display = 'none';
  } else {
    // Show wishlist items
    emptyWishlistElement.style.display = 'none';
    wishlistGridElement.style.display = 'block';
    renderGrid(wishlistItems);
  }
}

// Render wishlist grid with items
function renderGrid(wishlistItems) {
  console.log('renderGrid function called with:', wishlistItems);
  
  // Clear existing content
  wishlistGridElement.innerHTML = '';
  
  // Create wishlist items
  wishlistItems.forEach(item => {
    const wishlistItem = createWishlistItem(item);
    wishlistGridElement.appendChild(wishlistItem);
  });
}

// Create individual wishlist item element
function createWishlistItem(item) {
  const itemElement = document.createElement('div');
  itemElement.className = 'wishlist-item';
  const title = item.title || item.name || 'Untitled Item';
  const priceNum = Number(item.price);
  const priceText = Number.isFinite(priceNum) ? priceNum.toFixed(2) : '0.00';
  const placeholder = 'data:image/svg+xml;utf8,' + encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 300 400"><rect width="300" height="400" fill="#f3ede6"/><text x="50%" y="50%" dominant-baseline="middle" text-anchor="middle" font-family="Inter, Arial" font-size="16" fill="#8b7d6b">No image</text></svg>');
  const imageSrc = item.image || (item.images && item.images.main) || placeholder;
  itemElement.innerHTML = `
    <div class="wishlist-item-image">
      <img src="${imageSrc}" alt="${title}" loading="lazy">
      <button class="remove-from-wishlist-btn" data-product-id="${item.id}">
        <i class="ri-heart-fill"></i>
      </button>
    </div>
    <div class="wishlist-item-details">
      <h3 class="wishlist-item-title">${title}</h3>
      <p class="wishlist-item-price">$${priceText}</p>
      <div class="wishlist-item-actions">
        <button class="add-to-cart-btn" data-product-id="${item.id}">
          <i class="ri-shopping-cart-line"></i>
          Add to Cart
        </button>
        <button class="remove-btn" data-product-id="${item.id}">
          <i class="ri-delete-bin-line"></i>
          Remove
        </button>
      </div>
    </div>
  `;
  
  // Add event listeners
  const removeBtn = itemElement.querySelector('.remove-from-wishlist-btn');
  const removeBtn2 = itemElement.querySelector('.remove-btn');
  const addToCartBtn = itemElement.querySelector('.add-to-cart-btn');
  
  removeBtn.addEventListener('click', () => removeFromWishlist(item.id));
  removeBtn2.addEventListener('click', () => removeFromWishlist(item.id));
  addToCartBtn.addEventListener('click', () => addToCartFromWishlist(item));
  
  return itemElement;
}

// Remove item from wishlist
function removeFromWishlist(productId) {
  try {
    removeWishlistShared(productId);
    
    // Re-render the wishlist
    renderWishlist();
    
    console.log('Item removed from wishlist:', productId);
  } catch (error) {
    console.error('Error removing item from wishlist:', error);
  }
}

// Add item to cart from wishlist
async function addToCartFromWishlist(item) {
  try {
    // Require auth; redirect to login if needed
    try {
      const res = await fetch('/api/auth/me', { credentials: 'include' });
      if (!res.ok) {
        const returnTo = encodeURIComponent(window.location.pathname + window.location.search);
        window.location.href = `/login?returnTo=${returnTo}`;
        return;
      }
    } catch (_) {
      const returnTo = encodeURIComponent(window.location.pathname + window.location.search);
      window.location.href = `/login?returnTo=${returnTo}`;
      return;
    }

    const cartItem = {
      id: item.id,
      size: 'M',
      quantity: 1,
      price: item.price,
      image: item.image,
      title: item.title
    };

    addToCart(cartItem);
    
    // Show success message
    showMessage('Item added to cart!', 'success');
    
    console.log('Item added to cart from wishlist:', item);
  } catch (error) {
    console.error('Error adding item to cart:', error);
  }
}

// Show message function
function showMessage(message, type = 'info') {
  // Create message element
  const messageDiv = document.createElement('div');
  messageDiv.className = `message message-${type}`;
  messageDiv.textContent = message;
  messageDiv.style.cssText = `
    position: fixed;
    top: 20px;
    right: 20px;
    background: ${type === 'success' ? '#4CAF50' : '#f44336'};
    color: white;
    padding: 12px 20px;
    border-radius: 4px;
    z-index: 1000;
    font-family: 'Inter', sans-serif;
  `;
  
  document.body.appendChild(messageDiv);
  
  // Remove after 3 seconds
  setTimeout(() => {
    if (messageDiv.parentNode) {
      messageDiv.remove();
    }
  }, 3000);
}

// Export for use in other scripts (for future functionality)
window.wishlistFunctions = {
  renderGrid,
  loadWishlistFromStorage
};
